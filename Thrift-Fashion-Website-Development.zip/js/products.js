function product(pid, name, price, calories, ingredient) {
    this.pid = pid;
    this.name = name;
    this.price = price;
    this.cal = calories;
	this.ingredient = ingredient;
}